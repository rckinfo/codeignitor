
<?php
echo "<h1>Welcome to CodeIgniter, $name!</h1>";
