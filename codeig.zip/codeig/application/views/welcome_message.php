<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$name="John Doe";
echo "<h1>Welcome to CodeIgniter, $name!</h1>";
?>
